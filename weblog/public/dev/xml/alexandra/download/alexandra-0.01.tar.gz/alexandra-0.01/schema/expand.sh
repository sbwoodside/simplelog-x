#!/bin/sh

# copyright (C) 2002-3 Simon Woodside
# under GPL. See LICENSE

xsltproc expand.xsl input.rng > 01.rng
xsltproc expand.xsl 01.rng > 02.rng
xsltproc expand.xsl 02.rng > 03.rng
xsltproc expand.xsl 03.rng > 04.rng
xsltproc expand.xsl 04.rng > 05.rng
xsltproc expand.xsl 05.rng > 06.rng
xsltproc expand.xsl 06.rng > 07.rng
xsltproc expand.xsl 07.rng > 08.rng
xsltproc expand.xsl 08.rng > 09.rng
xsltproc expand.xsl 09.rng > 10.rng
xsltproc expand.xsl 10.rng > 11.rng
xsltproc expand.xsl 11.rng > 12.rng
xsltproc expand.xsl 12.rng > 13.rng
xsltproc expand.xsl 13.rng > 14.rng
echo 'ref count in input.rng is '
grep -c '<ref ' input.rng
echo 'ref count in 14.rng is '
grep -c '<ref ' 14.rng