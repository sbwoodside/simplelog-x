//RivenResourceFile
//This class is intended to be used to access the resource files
//used in the game Riven by Cyan Corp. (also made Myst).
//Currently only copying of sound resources is implemented.
//This clode is public domain and may be modified and redistributed freely;
//if you do modify and release it, please let me (Simon Woodside) know at
//sbwoodside@uwaterloo.ca  http://www.simonwoodside.home.ml.org/


//set tab stops to 2 spaces





import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import java.lang.Math.*;
import java.awt.*;

public class RivenResourceFile {
	
	// This class accepts the name of a Riven Resource File (.MHK)
	// and reads it in, allowing easy access to the information stored
	// within.
	

// Private Inline Classes
	private class ResourceInfo {
		/* Fields */
		public short 		localResourceID;
		public short 		globalResourceIndex;
		public String		name;
		/* Methods */
		public ResourceInfo () { localResourceID = 0; globalResourceIndex = 0; name = new String(""); }
		public short getGlobalResourceIndex() { return (short)globalResourceIndex; }
		public String toString() {
			return "ResourceInfo{" + /*"localResourceID = " + localResourceID + 
				", globalResourceIndex = " + globalResourceIndex + 
				*/", name = '" + name + "' }";
		}
	}
	
	private class LocalResourceTable {
		/* Fields */
		public short				numberOfResources;
		public String				tag;
		public short				startOffset;	/* from start of directory */
		public short				endOffset;	/* from start of directory */
		public ResourceInfo[]	resourceInfo;
		/* Methods */
		public LocalResourceTable () { numberOfResources = 0; }
		public String toString() {
			String temp;
			temp = "LocalResourceTable{ numberOfResources = " + numberOfResources + 
				", tag = " + tag +
				", startOffset = " + startOffset + ", endOffset = " + endOffset +
				", resourceInfo = ";
			if ( resourceInfo == null ) { temp += "null"; }
			else {	for ( int i = 0 ; i < resourceInfo.length ; i++ ) {	temp += resourceInfo[i].toString() + ", ";	}	}
			temp += "}";
			return temp;
		}
	} /* LocalResourceTable */
	
	private class GlobalResourceInfo {
		public int		offsetWithinFile;
		public int		resourceSize;
		public byte		resourceFlags;
		public short	unknown;
		public GlobalResourceInfo () { offsetWithinFile = 0; resourceSize = 0; resourceFlags = 0; unknown = 0; }
	} /* GlobalResourceInfo */
	
	private class Header {
		public int 		numberOfGlobalResources		= 0;
		public short 	numberOfLocalResourceTypes		= 0;
		public int		offsetOfDirectory				= 0;
		
		public int		fileLength						= 0;
		public short 	offsetOfGlobalRsrcTable			= 0;
		public short 	sizeOfGlobalRsrcTable			= 0;
		
		public short	offsetOfResourceNames			= 0;
		
		public GlobalResourceInfo[]		globalResourceInfo;			/* Stores the table of global resources referenced thru the next list of tables */
		public LocalResourceTable[]		localResourceTable;		/* This array will store all of the local resource tables */
		
		public void Header() { /* do nothing */ }
		public LocalResourceTable getLocalResourceInfoTable( String Tag ) {
 			for ( int i = 0; i < localResourceTable.length; i++ ) {
 				if ( localResourceTable[i].tag.equals(Tag) ) {
					return localResourceTable[i];
				}
			}
			return null;
		}
		public ResourceInfo getLocalResourceInfo( String Tag, int Index ) {
		int i;
		boolean found = false;
			for ( i = 0; i < localResourceTable.length; i++ ) {
				if ( localResourceTable[i].tag.equals(Tag) ) {
					found = true;
					break;
				}
			}
			if (found)
				return localResourceTable[i].resourceInfo[Index];
			else
				return null;
		}
		public GlobalResourceInfo getGlobalResource( short Index ) {
			return globalResourceInfo[Index];
		}
		public void Print() {
			System.out.println();
			System.out.println( "HEADER PRINTOUT:" );
			System.out.println( "numberOfGlobalResources = " + numberOfGlobalResources );
			System.out.println( "numberOfLocalResourceTypes = " + numberOfLocalResourceTypes );
			System.out.println( "fileLength = " + fileLength );
			System.out.println( "offsetOfGlobalRsrcTable = " + offsetOfGlobalRsrcTable );
			System.out.println( "sizeOfGlobalRsrcTable = " + sizeOfGlobalRsrcTable );
			System.out.println( "offsetOfResourceNames = " + offsetOfResourceNames );
			System.out.println( "globalResourceInfo = " + globalResourceInfo );
			if (localResourceTable == null) { System.out.println( "localResourceTable = null"); }
			else {	
				String temp = "";
				for ( int i = 0 ; i < localResourceTable.length ; i++ ) {
					temp += localResourceTable[i].toString() + ", \n";
				}
				System.out.println( "localResourceTable = {" + temp + "}" ); }
			System.out.println( " = " + "" );
			System.out.println( " = " + "" );
			System.out.println( " = " + "" );
			System.out.println( "DONE." );
			System.out.println();
		}
	}
	
	





// Private Variables
	private Hashtable 				resourceTable			= new Hashtable();	/* perhaps this will eventually be used */
	private String						filename;				/* the name of the file */
	private File							infile;					/* the "file" object - convienience */
	private RandomAccessFile 	inStream;				/* the stream */
	private Header						header;				/* where we store all the info we get. */

	
	
	
		
	
	
	
	public void SaveSound( int index, String outfilename ) 
	{
	int i;
	short 							globalResourceIndex;
	int 								offset, size;
	ResourceInfo 				soundInfo;
	GlobalResourceInfo 	resourceInfo;
	byte								buf;
	FileDialog					fileDialog;
//	String							outfilename;
//	File								outfile;
//	RandomAccessFile		outStream;	BufferedOutputStream boutStream;
	
		//first we have to find the list of sounds
		//it's in the localResourceTable with tag = "tWAV"
		soundInfo 					= header.getLocalResourceInfo( "tWAV", index );
		globalResourceIndex = soundInfo.getGlobalResourceIndex(); //zero-bases it
		resourceInfo 				= header.getGlobalResource( globalResourceIndex );
		
		size 		= resourceInfo.resourceSize;
		offset 	= resourceInfo.offsetWithinFile;
		
//		outfilename = soundInfo.name + ".adpcm";
		//now all we have to do is copy soundTable[index] to a new file
		if (outfilename != null) {			// The user didn't press cancel
//			outfile = new File( outfilename );
	
			try {			boutStream = new BufferedOutputStream(											new FileOutputStream(outfilename));//			outStream = new RandomAccessFile ( outfile, "rw" );
						
			i = offset;
			inStream.seek( offset );
			while ( i++ < offset + size )
			{
				buf = inStream.readByte( );	//even if it works, really slow and inefficient
				boutStream.write( buf );
			}
			
			boutStream.close();
			}
			catch (java.io.IOException e) 
			{
			System.out.println("RivenResourceFile: SaveSound failed due to IOException: " + e);
			}
		}
		//and that's that.
	}
	
	

		
		
			public boolean init( String filename )	{		header = new Header();
		
		infile = new File( filename );
		// use the calls to check stuff about the file?
		try {
			inStream = new RandomAccessFile ( infile, "r" );
			
//			if ( inStream == null ) {		System.out.println("inStream == null is TRUE");	}
			return true;		}
		catch (java.io.IOException e) {
			System.out.println("RivenResourceFile: ReadHeader failed due to IOException: " + e);
			return false;
		}	}	public boolean close()	{		try {
		inStream.close();		return true;
		}
		catch (java.io.IOException e) {
			System.out.println("RivenResourceFile: ReadHeader failed due to IOException: " + e);
			return false;
		}	}

		
	// assume filename is a valid MHK file
	// MHK file is big-endian
	/* The important information we need to get here is:	*/
	/* - the list of tables of local resources.				*/
	/*		(there is one for each type of resource, each	*/
	/*		table contains the list of resources, their		*/
	/*		names, and where they're found in the global	*/
	/*		resource table I think..)						*/ 
	/* - the table of global resources (contains offsets		*/
	/* 		within the file of each resource)				*/
	public boolean ReadHeader( String filename )
	{
		// ReadInt gives 4 bytes!
		// ReadShort gives 2 bytes!!!
		// ReadLong gives 8 bytes!!!
		// Read the MHK file from the given file name
		// into the internal variables
		
		try {
			inStream = new RandomAccessFile ( infile, "r" );
			
			// Read the file header
			ReadFileHeader();
			
			// Read the resource directory
			{
				// resource type table - a table of all the types of resources found
				// in the file.
				ReadResourceTypeTable();
				//local resource tables (one per type)
				ReadLocalResourceTables();
				// resource names - add these to the local resource tables.
				ReadResourceNames();
				/* global resource table */
				/* Used to find the resources in the file */
				ReadGlobalResourceTable();
			} /* resource directory */
			
			//header.Print();
			
			// everything from here on is the actual data.
			// read the data we want
			// (right now we only read the header in this function)
			
			return true;
		}
		catch (java.io.IOException e) {
			System.out.println("RivenResourceFile: ReadHeader failed due to IOException: " + e);
			return false;
			}
	} /* ReadHeader */
	










		/* return an array containing the list of sound */	/* resources.																		*/	public String[] GetSoundList() {		String[]						result			= null;		LocalResourceTable	soundTable;		soundTable = header.getLocalResourceInfoTable("tWAV");
		if( soundTable != null )		{			result = new String[soundTable.numberOfResources];			for( int i = 0; i < soundTable.numberOfResources; i++ )			{				result[i] = soundTable.resourceInfo[i].name;			}		}		return result;	}	
	/* print stats about what we found in the file */
	public void PrintStats() {
	/* Var */
	int 		foundIndex 	= 0;
	boolean	found		= false;
	LocalResourceTable	soundTable;
	GlobalResourceInfo 	resourceInfo;

		soundTable = header.getLocalResourceInfoTable( "tWAV" );
		if ( soundTable != null ) 
		{
			System.out.println( "Found" + soundTable.numberOfResources + " WAVEADPC resources." );
			System.out.println( "With names:" );
			for ( int i = 0 ; i < soundTable.numberOfResources ; i++ )
			{
				resourceInfo = header.getGlobalResource( soundTable.resourceInfo[i].globalResourceIndex );
				System.out.println( "   " + i + ". " + soundTable.resourceInfo[i].name +
														" (offset: " + resourceInfo.offsetWithinFile +
														", size: " + resourceInfo.resourceSize + ")" );
			} //for
		} //if
		System.out.println( "End of listing." );
	} /* PrintStats */












/* ReadFileHeader */
/* Seems OK */
private void ReadFileHeader() throws java.io.IOException
{
/* Var */
double		garbage, fileLength;
int			offsetOfGlobalRsrcTable, sizeOfGlobalRsrcTable;

	garbage 												= inStream.readInt();	// "MHWK"
	garbage 												= inStream.readInt();	// file length - 8
	garbage 												= inStream.readInt();	// "RSRC"
	garbage 												= inStream.readInt();	// always 01000000 hex
	header.fileLength 							= inStream.readInt();	// file length
	header.offsetOfDirectory				= inStream.readInt();	// offset of dir, always 0000001C hex
	header.offsetOfGlobalRsrcTable 	= inStream.readShort();		// offset withing dir, of global rsrcs table
	header.sizeOfGlobalRsrcTable 		= inStream.readShort();		// size of global resource table.
} /* ReadFileHeader */

// resource type table
// local resource tables (one per type)	"localResourceTable"
// resource names
// global resource table					"globalResourceTable"
private void ReadResourceTypeTable() throws java.io.IOException
{
/* Var */
byte[]		temp		= new byte[4];

	header.offsetOfResourceNames			= inStream.readShort();
	header.numberOfLocalResourceTypes	= inStream.readShort();
	
	header.localResourceTable					= new LocalResourceTable[header.numberOfLocalResourceTypes];
	
	for ( int i = 0 ;  i < header.numberOfLocalResourceTypes ; i++ ) {
		header.localResourceTable[i]							= new LocalResourceTable();
		inStream																	.readFully( temp );	// reads four bytes into the four byte buffer temp
		header.localResourceTable[i].tag 					= new String(temp);
		header.localResourceTable[i].startOffset	= inStream.readShort();
		header.localResourceTable[i].endOffset		= inStream.readShort();
	}
} /* ReadResourceType */
	
//local resource tables (one per type)
private void ReadLocalResourceTables() throws java.io.IOException
{
/* Var */
int					garbage;
	
	/* Get each of the tables */
	for ( int i = 0 ; i < header.numberOfLocalResourceTypes ; i++ ) {
		inStream											.seek( header.offsetOfDirectory + header.localResourceTable[i].startOffset );
	
		/* get number of resources of this type */
		header.localResourceTable[i]	.numberOfResources	= inStream.readShort();

		/* assign each of the local resource infos to a vector */
		/* check loop logic!!! ! */
		header.localResourceTable[i]	.resourceInfo		= new ResourceInfo[header.localResourceTable[i].numberOfResources];
		for ( int j = 0 ; j < header.localResourceTable[i].numberOfResources ; j++ ) {
			/* get the information	*/
			header.localResourceTable[i]	.resourceInfo[j]											= new ResourceInfo();
			header.localResourceTable[i]	.resourceInfo[j].localResourceID 			= inStream.readShort();	/* sometimes 1-based */
			header.localResourceTable[i]	.resourceInfo[j].globalResourceIndex	= inStream.readShort();
			header.localResourceTable[i]	.resourceInfo[j].globalResourceIndex	-= 1;	/* 1-based, so we subtract 1! */
		} /* for */
	} /* for */
} /* ReadLocalResourceTables */

// resource names
private void ReadResourceNames() throws java.io.IOException
{
	inStream.seek( header.offsetOfDirectory + header.offsetOfResourceNames );
	
	/* For each of the local resource tables */
	for( int i = 0 ; i < header.localResourceTable.length ; i++ ) {
		/* for each of the resources in the table */
		/* we only read the name if the first char of the resource type is "t", */
		/*	otherwise there isn't a name for that type.	*/
		if ( header.localResourceTable[i].tag.substring(0,1).equals("t") ) {
			for( int j = 0 ; j < header.localResourceTable[i].numberOfResources ; j++ ) {
				/* read in the name and store it */
				header.localResourceTable[i].resourceInfo[j].name = myReadString(inStream);
			} /* for */
		} /* if */
	} /* for */
} /* resource names */

/* global resource table */
/* This info is used by referencing it from the global resource index	*/
/* given in the info of each local resource							*/
private void ReadGlobalResourceTable() throws java.io.IOException
{
	inStream.seek( header.offsetOfDirectory + header.offsetOfGlobalRsrcTable );

	/* use globalResourceTable */
	/* read the number of global resources */
	header.numberOfGlobalResources 		= inStream.readInt();
//	System.out												.println( "Number of global RESOURCES = " + header.numberOfGlobalResources );
	
	header.globalResourceInfo					= new GlobalResourceInfo[header.numberOfGlobalResources];
	/* for each global resource, read its info into the global resource table */
	for( int i = 0 ; i < header.numberOfGlobalResources ; i++ ) {
		header.globalResourceInfo[i]	= new GlobalResourceInfo();
		header.globalResourceInfo[i]	.offsetWithinFile	= inStream.readInt();
		/* I'm not using readShort() because we get 2's complement negative errors if we do. */
		byte	part2										= inStream.readByte();
		byte	part3										= inStream.readByte();
		byte	part1										= inStream.readByte();
		header.globalResourceInfo[i]	.resourceSize					= (int)(Math.pow(2,16)*part1 + Math.pow(2,8)*part2 + part3);
		
//		System.out.println( "resourceSize = " + header.globalResourceInfo[i].resourceSize );
		header.globalResourceInfo[i]	.resourceFlags				= inStream.readByte();
		header.globalResourceInfo[i]	.unknown							= inStream.readShort();
	} /* for */
} /* global resource table */




	
	
	
	// should be called after ReadHeader
	public String toString() {
	String result;
	
		try {
			System.out.println(filename);
			System.out.println(infile);
			System.out.println(header);
		}
		catch (java.lang.NullPointerException e) {		System.out.println("NullPointerException caught.");	System.out.println(e); }
		//RivenResourceFile{resourceTable={}, infile=filename}
		result = "hi";
		return result;
	} /* toString */		
	
	
	
/*	public int numberOfResources() {
		// return the number of resources read in the file
		return 0;
	}
	public Hashtable resourceTable() {
		// return the Hashtable containing the table of resources,
		// with the name as key, info object as value
		return new Hashtable();
	}
	public String[] resourceNamesList() {
		// return a list of the names of the resources, which
		// are the keys for getting the information out of
		// the resourceTable.
		return new String[100];
	}
*/	
	
	
	int totalCount = 0;
	/* Can't read more that 500 characters. */
	/* reads from whereever the file pointer currently is at */
	private String myReadString( RandomAccessFile inStream ) throws java.io.IOException
	{
	byte[]		inputBytes	= new byte[500];
	int			i			= 0;
	
		/* read bytes from the in stream until we reach one that is 0 */
		try {	inputBytes[i] = inStream.readByte();	}
		catch (java.io.IOException e) {}
		while ( inputBytes[i] != 0 && i < 500) {
			i++;
			inputBytes[i] = inStream.readByte();
		}
		
		/* now inputBytes contains all the text we need, and we've read 	*/
		/* everything, including the extra null character.				*/
		if (i==500) {	return "exceeded input buffer size for myReadString";	}
		return new String(inputBytes);
	}
			
	
} /* RivenResourceFile */
