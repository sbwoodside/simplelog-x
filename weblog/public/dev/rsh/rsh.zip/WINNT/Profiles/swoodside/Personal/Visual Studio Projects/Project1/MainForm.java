import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

import RivenResourceFile;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'MainForm'
 * created in the main() method.
 */
public class MainForm extends Form
{
	RivenResourceFile	rivenResourceFile	= new RivenResourceFile();

	public MainForm()
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();
		
		loadFile();
		this.showDialog();

	}

	/**
	 * MainForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
		rivenResourceFile.close();
	}
	
	private void loadFile()
	{
		//FileDialog 		fileDialog;
		String				filename;		//fileDialog  			= new FileDialog(this, 
		//																		"Select a riven data file to open");
		//fileDialog.setDirectory( "." );		fileDialog.setInitialDir(".");
		//fileDialog.show();		fileDialog.showDialog();
		//filename = fileDialog.getFile();
		//filename = fileDialog.getDirectory() + filename;		filename = fileDialog.getFileName();
		
		if (filename != null) 
		{
			// The user didn't press cancel
			if ( rivenResourceFile.init(filename) )			{				if (rivenResourceFile	.ReadHeader( filename ) ) 
				{
//					rivenResourceFile	.PrintStats();					resourceList.setItems( rivenResourceFile.GetSoundList() );
				}				//rivenResourceFile.close();
				fileNameLabel.setText(filename);				console.addItem( "Successfully read file " + filename );
			}
			else 
			{
				console.addItem( "ERROR: Couldn't read the file header." ); //make a dialog
			}			
		}
		else
		{				console.addItem( "ERROR: No filename given.");
		}		
	}

	private void loadFile_click(Object source, Event e)
	{
		loadFile();
	}

	private void btnSave_click(Object source, Event e)
	{
	String outfilename;
		int number;
		
//		number = Integer.parseInt(resourceNumber.getText());
		number = resourceList.getSelectedIndex();
		//fileDialog = new FileDialog(frame, "Save the sound file as:", FileDialog.SAVE);
		//fileDialog.setDirectory( "." );
		//fileDialog.setName( outfilename );
		//fileDialog.show();
		//outfilename = fileDialog.getDirectory() + fileDialog.getFile();		saveFileDialog.setInitialDir(".");		saveFileDialog.setFileName( resourceList.getSelectedItem() + ".waveadpcm" );		saveFileDialog.showDialog();		outfilename = saveFileDialog.getFileName();

		console.addItem( "Saving file " + outfilename );
		rivenResourceFile	.SaveSound(number, outfilename);
		console.addItem( "Successfully saved file " + outfilename );
	}

	private void resourceList_selectedIndexChanged(Object source, Event e)
	{
		resourceNumber.setText(String.valueOf(resourceList.getSelectedIndex()));
	}

	/**
	 * NOTE: The following code is required by the Visual J++ form
	 * designer.  It can be modified using the form editor.  Do not
	 * modify it using the code editor.
	 */
	Container components = new Container();
	Edit resourceNumber = new Edit();
	Label label1 = new Label();
	Button btnSave = new Button();
	ListBox console = new ListBox();
	Button loadFile = new Button();
	OpenFileDialog fileDialog = new OpenFileDialog();
	SaveFileDialog saveFileDialog = new SaveFileDialog();
	ListBox resourceList = new ListBox();
	Edit fileNameLabel = new Edit();

	private void initForm()
	{
		this.setText("Riven Sound Hack");
		this.setAutoScaleBaseSize(new Point(5, 13));
		this.setClientSize(new Point(313, 247));

		resourceNumber.setBackColor(Color.CONTROL);
		resourceNumber.setLocation(new Point(144, 136));
		resourceNumber.setSize(new Point(56, 20));
		resourceNumber.setTabIndex(0);
		resourceNumber.setText("");
		resourceNumber.setReadOnly(true);

		label1.setLocation(new Point(88, 136));
		label1.setSize(new Point(88, 16));
		label1.setTabIndex(1);
		label1.setTabStop(false);
		label1.setText("Resource:");

		btnSave.setLocation(new Point(224, 136));
		btnSave.setSize(new Point(75, 23));
		btnSave.setTabIndex(2);
		btnSave.setText("Save");
		btnSave.addOnClick(new EventHandler(this.btnSave_click));

		console.setLocation(new Point(8, 176));
		console.setSize(new Point(296, 56));
		console.setTabIndex(3);
		console.setText("listBox1");
		console.setUseTabStops(true);

		loadFile.setLocation(new Point(16, 16));
		loadFile.setSize(new Point(88, 23));
		loadFile.setTabIndex(4);
		loadFile.setText("Load new file");
		loadFile.addOnClick(new EventHandler(this.loadFile_click));

		/* @designTimeOnly fileDialog.setLocation(new Point(64, 200)); */

		/* @designTimeOnly saveFileDialog.setLocation(new Point(184, 200)); */

		resourceList.setLocation(new Point(136, 16));
		resourceList.setSize(new Point(160, 95));
		resourceList.setTabIndex(7);
		resourceList.setText("listBox1");
		resourceList.setUseTabStops(true);
		resourceList.addOnSelectedIndexChanged(new EventHandler(this.resourceList_selectedIndexChanged));

		fileNameLabel.setBackColor(Color.CONTROL);
		fileNameLabel.setLocation(new Point(16, 56));
		fileNameLabel.setSize(new Point(100, 56));
		fileNameLabel.setTabIndex(8);
		fileNameLabel.setText("edit1");
		fileNameLabel.setMultiline(true);
		fileNameLabel.setReadOnly(true);

		this.setNewControls(new Control[] {
												fileNameLabel, 
												resourceList, 
												loadFile, 
												console, 
												btnSave, 
												resourceNumber, 
												label1});
	}

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new MainForm());
	}
}
