import java.awt.*;
import RivenResourceFile;

public class RivenSoundHack 
	extends Frame
{
	/* Global variables */
	private static Frame 	frame;
	FileDialog 			fileDialog;
	String				filename;
	RivenResourceFile	rivenResourceFile	= new RivenResourceFile();
	
	public RivenSoundHack () 
	{
		Panel p = new Panel();
		/* put in a textfield */
		
		fileDialog  			= new FileDialog(this, 
																				"Select a riven data file to open",
																				FileDialog.LOAD);
		fileDialog.setDirectory( "." );
		fileDialog.show();
		filename = fileDialog.getFile();
		filename = fileDialog.getDirectory() + filename;
		
		if (filename != null) 
		{
			// The user didn't press cancel
			if ( rivenResourceFile.init(filename) )			{				if (rivenResourceFile	.ReadHeader( filename ) ) 
				{
					rivenResourceFile	.PrintStats();
					//now we must provide some way for the user to choose which sound they
					//want to save
					//rivenResourceFile	.SaveSound(0, this);				}				rivenResourceFile.close();
			}
			else 
			{
				System.out.println( "ERROR: Couldn't read the file header." ); //make a dialog
			}
			// For each sound,
			//	Open a file for output with the same name in a new directory inside the directory the input
			//	file came from.
			//	Give the output file the name of the sound .adpcm (? .wave?)
			//	Create a header and write it to the file
			//	Read in the right section of the data in the input file
			//	Write that data out to the output file
			//	Close the the output file
			//	(Maintain a progress bar while doing this?)
			
			//	Prompt the user to choose another file.  If they hit cancel, quit the loop (which quits the app)
			
		}
		else
		{	System.out.println( "No filename given.");
		}
		
		System.out.println( "RivenSoundHack done." );
	}
	
	/*
	public static void main( String[] args )
	{
		frame = new RivenSoundHack();
		frame.setSize( 200, 100 );
		frame.setLocation( 100, 100 );
		frame.show();
	// because this is a static function we can't put our references to fileDialog here! 
	}*/
}
			
