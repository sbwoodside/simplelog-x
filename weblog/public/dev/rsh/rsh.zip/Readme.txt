RivenSoundHack
Alpha 2 Developer Release

Distributed as open source under the GPL (GNU public license).


This is the second release of RivenSoundHack.  As such, it is still rough.
Not all features have been added.  The file copy needs work, and I need to
put headers on the sound files so they can be played.

To use the program, you need to:

	- note that RSH is a Java application, not a Java applet.  So, you need
	to download a java runtime system.  This usually comes with a Java
	developer kit, but might be available separately, as on the Mac OS.
	
	- download JDK 1.1.x for your system (May be available at java.sun.com,
	www.apple.com in the developer directory, or www.microsoft.com)
	
	- if you have a Macintosh, download MRJ (Macintosh Runtime for Java) from
	http://www.apple.com/macos/java/.  Download MRJ 2.0.

	- on Windows I have been using Visual J++.  I'm not sure what free
	options exist for running Java applications.


Instructions to get started with RSH:

	- RSH is a java application (as opposed to a java applet which runs on
	your web browser).
	
	- Once you have installed the java runtimes in the steps above, and
	according to the instructions given with those packages, type:

		java RivenSoundHack
		
	from within the directory where you have placed this application.

	- Or, if you have a Macintosh, drag the file RivenSoundHack.class onto the
	JBindery application and click "Run".  A double-clickable application will
	be a part of a later version.
	
	- this will run RSH.


Using RivenSoundHack:

	- RSH displays a window where you must select a Riven resource file.
	These are files ending in .MHK.  I suggest you choose a file from
	CD-ROM #1 in the Assets1 or Assets2 folder as these are the only
	sound resource files.  They may also be stored in the "Data" folder
	on your hard drive.

	- You'll see a list of the sound resources in the file on your screen.
	If nothing shows up, there aren't any SOUND resources in that file.

	- Then, click Save to save the individual resources to your disk.
	The copy is really slow, so be patient.

	- Right now the only way to play the files that I know of is to use
	SoundHack on Mac OS (http://www.hitsquad.com/smm/programs/SoundHack/).  
	Open the file as headerless data, then fake the header to be 22.050 kHz,
	2 channel, 4-bit ADPCM data.  Hit play and it should sound pretty good.


RSH has not been tested with versions of Java earlier than 1.1.

Feedback send to sbwoodside@uwaterloo.ca.


---
Simon B. Woodside
July 28, 1997
sbwoodside@uwaterloo.ca
simonwoodside.home.ml.org
