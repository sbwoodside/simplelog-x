import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import java.lang.Math.*;

public class RivenResourceFile {
	
	// This class accepts the name of a Riven Resource File (.MHK)
	// and reads it in, allowing easy access to the information stored
	// within.
	

// Private Classes
	private class ResourceInfo {
		/* Fields */
		public short 		localResourceID;
		public short 		globalResourceIndex;	// 1-based!
		public String		name;
		
		/* Methods */
		public ResourceInfo () { localResourceID = 0; globalResourceIndex = 0; name = new String(""); }
		public String toString() {
			return "ResourceInfo{ " + /*"localResourceID = " + localResourceID + 
				", globalResourceIndex = " + globalResourceIndex + 
				*/", name = " + name + "}";
		}
	}
	
	private class LocalResourceTable {
		/* Fields */
		public short				numberOfResources;
		//public int				tag;
		public String			tag;
		public short				startOffset;	/* from start of directory */
		public short				endOffset;	/* from start of directory */
		public ResourceInfo[]	resourceInfo;
		
		/* Methods */
		public LocalResourceTable () { numberOfResources = 0; }
		public String toString() {
			String temp;
			temp = "LocalResourceTable{ numberOfResources = " + numberOfResources + 
				", tag = " + tag +
				", startOffset = " + startOffset + ", endOffset = " + endOffset +
				", resourceInfo = ";
			if ( resourceInfo == null ) { temp += "null"; }
			else {	for ( int i = 0 ; i < resourceInfo.length ; i++ ) {	temp += resourceInfo[i].toString() + ", ";	}	}
			temp += "}";
			return temp;
		}
	} /* LocalResourceTable */
	
	
	
	private class GlobalResourceInfo {
		public int		offsetWithinFile;
		public int		resourceSize;
		public byte		resourceFlags;
		public short		unknown;
		public GlobalResourceInfo () { offsetWithinFile = 0; resourceSize = 0; resourceFlags = 0; unknown = 0; }
	} /* GlobalResourceInfo */
	
	private class Header {
		public int 		numberOfGlobalResources		= 0;
		public short 	numberOfLocalResourceTypes		= 0;
		public int		offsetOfDirectory				= 0;
		
		public int		fileLength						= 0;
		public short 	offsetOfGlobalRsrcTable			= 0;
		public short 	sizeOfGlobalRsrcTable			= 0;
		
		public short		offsetOfResourceNames			= 0;
		
		public GlobalResourceInfo[]		globalResourceInfo;			/* Stores the table of global resources referenced thru the next list of tables */
		public LocalResourceTable[]		localResourceTable;		/* This array will store all of the local resource tables */
		
		public void Header() { /* do nothing */ }
		public void Print() {
			System.out.println();
			System.out.println( "HEADER PRINTOUT:" );
			System.out.println( "numberOfGlobalResources = " + numberOfGlobalResources );
			System.out.println( "numberOfLocalResourceTypes = " + numberOfLocalResourceTypes );
			System.out.println( "fileLength = " + fileLength );
			System.out.println( "offsetOfGlobalRsrcTable = " + offsetOfGlobalRsrcTable );
			System.out.println( "sizeOfGlobalRsrcTable = " + sizeOfGlobalRsrcTable );
			System.out.println( "offsetOfResourceNames = " + offsetOfResourceNames );
			System.out.println( "globalResourceInfo = " + globalResourceInfo );
			if (localResourceTable == null) { System.out.println( "localResourceTable = null"); }
			else {	
				String temp = "";
				/*This is a bitch */
				for ( int i = 0 ; i < localResourceTable.length ; i++ ) {
					temp += localResourceTable[i].toString() + ", \n";
				}
				System.out.println( "localResourceTable = {" + temp + "}" ); }
			System.out.println( " = " + "" );
			System.out.println( " = " + "" );
			System.out.println( " = " + "" );
			System.out.println( "DONE." );
			System.out.println();
		}
	}
	
	
// Private Variables
	private Hashtable 				resourceTable			= new Hashtable();	/* perhaps this will eventually be used */
	private String					filename;				/* the name of the file */
	private File						infile;					/* the "file" object - convienience */
	private RandomAccessFile 		inStream;				/* the stream */
	private Header					header;				/* where we store all the info we get. */

	
	
	// new
	public RivenResourceFile () {
		// don't do anything
	}
	
	
	/* print stats about what we found in the file */
	public void PrintStats() {
	/* Var */
	int 		foundIndex 	= 0;
	boolean	found		= false;
	
		for ( int i = 0 ; i < header.numberOfLocalResourceTypes ; i++ ) {
			if ( header.localResourceTable[i].tag.equals("tWAV") ) {
				System.out.println( "Found " + header.localResourceTable[i].numberOfResources + " WAVEADPC resources." );
				found = true;
				foundIndex = i;
			}
		} /* for */
		System.out.println( "And the names are:" );
		if (found) {
			for ( int i = 0 ; i < header.localResourceTable[foundIndex].numberOfResources ; i++ ) {
				System.out.println( "     " + i + ".  " + header.localResourceTable[foundIndex].resourceInfo[i].name +
					" (offset: " + 
					header.globalResourceInfo[header.localResourceTable[foundIndex].resourceInfo[i].globalResourceIndex].offsetWithinFile +
					" size: " +
					header.globalResourceInfo[header.localResourceTable[foundIndex].resourceInfo[i].globalResourceIndex].resourceSize +
					" )"
					);
			} /* for */
		} /* if */
		System.out.println( "End of listing." );
	} /* PrintStats */
		
		
		
// assume filename is a valid MHK file
// MHK file is big-endian
/* The important information we need to get here is:	*/
/* - the list of tables of local resources.				*/
/*		(there is one for each type of resource, each	*/
/*		table contains the list of resources, their		*/
/*		names, and where they're found in the global	*/
/*		resource table I think..)						*/ 
/* - the table of global resources (contains offsets		*/
/* 		within the file of each resource)				*/
public boolean ReadHeader( String filename )
{
/* Var */

	// ReadInt gives 4 bytes!
	// Read Short gives 2 bytes!!!
	// ReadLong gives 8 bytes!!!
	// Read the MHK file from the given file name
	// into the internal variables
	
	header = new Header();
	
	// use FSM?
/*	System.out.println("RivenResourceFile: filename I got is: " + filename);
*/	infile = new File( filename );
	// use the calls to check stuff about the file?
	try {
/*		System.out.println("Before, inStream = " + inStream);
*/		inStream = new RandomAccessFile ( infile, "r" );
/*		System.out.println("And inStream = " + inStream);
*/		
		if ( inStream == null ) {		System.out.println("inStream == null is TRUE");	}
		
		// Read the file header
		ReadFileHeader();
		
		// Read the resource directory
		{
			// resource type table - a table of all the types of resources found
			// in the file.
			ReadResourceTypeTable();
			//local resource tables (one per type)
			ReadLocalResourceTables();
			// resource names - add these to the local resource tables.
			ReadResourceNames();
			/* global resource table */
			/* Used to find the resources in the file */
			ReadGlobalResourceTable();
		} /* resource directory */
		
		header.Print();
		
		// everything from here on is the actual data.
		// read the data we want
		// (right now we only read the header in this function)
		inStream.close();
		
		return true;		/* This should return whether the read worked		*/
						/* or not... or maybe use an exception.				*/
	}
	catch (java.io.IOException e) { System.out.println("RivenResourceFile: ReadHeader failed because of exception: " + e);
								return false; }
/*	catch (java.lang.NullPointerException e) { System.out.println("RivenResourceFile: ReadHeader failed because of exception: " + e);
								return false; }
*/} /* ReadHeader */
	
	
/* ReadFileHeader */
/* Seems OK */
private void ReadFileHeader() throws java.io.IOException
{
/* Var */
double		garbage, fileLength;
int			offsetOfGlobalRsrcTable, sizeOfGlobalRsrcTable;

	garbage 				= inStream.readInt();	// "MHWK"
	garbage 				= inStream.readInt();	// file length - 8
	garbage 				= inStream.readInt();	// "RSRC"
	garbage 				= inStream.readInt();	// always 01000000 hex
	header.fileLength 	= inStream.readInt();	// file length
	header.offsetOfDirectory			= inStream.readInt();	// offset of dir, always 0000001C hex
	header.offsetOfGlobalRsrcTable 	= inStream.readShort();		// offset withing dir, of global rsrcs table
	header.sizeOfGlobalRsrcTable 		= inStream.readShort();		// size of global resource table.
} /* ReadFileHeader */



// resource type table
// local resource tables (one per type)	"localResourceTable"
// resource names
// global resource table					"globalResourceTable"
private void ReadResourceTypeTable() throws java.io.IOException
{
/* Var */
//Double[]	resourceTypesList;			/* array - stores the list of resource types. */
byte[]		temp		= new byte[4];

	header.offsetOfResourceNames		= inStream.readShort();
	header.numberOfLocalResourceTypes	= inStream.readShort();
	
	header.localResourceTable		= new LocalResourceTable[header.numberOfLocalResourceTypes];
	
/*	header.Print();
	System.out.println("numberOflocalresourcetypes = " + header.numberOfLocalResourceTypes);
	resourceTypesList 	= new Double[header.numberOfLocalResourceTypes];
*/	for ( int i = 0 ;  i < header.numberOfLocalResourceTypes ; i++ ) {
/*		System.out.println("i = " + i);
*/		header.localResourceTable[i]				= new LocalResourceTable();
//		header.localResourceTable[i].tag 			= inStream.readInt();	//actually we should be reading four characters since it's a four char string.
												inStream.readFully( temp );	// reads four bytes into the four byte buffer temp
		header.localResourceTable[i].tag 			= new String(temp);
		header.localResourceTable[i].startOffset	= inStream.readShort();
		header.localResourceTable[i].endOffset	= inStream.readShort();
	}
	/* OK */
} /* ReadResourceType */
	
	
//local resource tables (one per type)
private void ReadLocalResourceTables() throws java.io.IOException
{
/* Var */
int					garbage;
//ResourceInfo[]		localResourceInfoList;
//LocalResourceTable	localResourceTable;
	
//	header.localResourceTable = new LocalResourceTable[header.numberOfLocalResourceTypes];
	/* now get each of the tables */
	for ( int i = 0 ; i < header.numberOfLocalResourceTypes ; i++ ) {
		/* Jump to the correct position in the file */
		inStream.seek( header.offsetOfDirectory + header.localResourceTable[i].startOffset );
	
		/* wipe the local resource table */
/*		localResourceTable 	= new LocalResourceTable();
*/		
		/* get number of resources of this type */
		header.localResourceTable[i].numberOfResources	= inStream.readShort();

		/* assign each of the local resource infos to a vector */
		/* check loop logic!!! ! */
/*		localResourceInfoList = new ResourceInfo[ localResourceTable.numberOfResources ];
*/		header.localResourceTable[i].resourceInfo		= new ResourceInfo[header.localResourceTable[i].numberOfResources];
		for ( int j = 0 ; j < header.localResourceTable[i].numberOfResources ; j++ ) {
			/* get the information	*/
/*			ResourceInfo resourceInfo 		= new ResourceInfo();
			resourceInfo	.localResourceID 	= inStream.readShort();
			resourceInfo	.globalResourceIndex	= inStream.readShort();
*/			header.localResourceTable[i].resourceInfo[j]						= new ResourceInfo();
			header.localResourceTable[i].resourceInfo[j].localResourceID 		= inStream.readShort();	/* sometimes 1-based */
			header.localResourceTable[i].resourceInfo[j].globalResourceIndex	= inStream.readShort();
			header.localResourceTable[i].resourceInfo[j].globalResourceIndex	-= 1;	/* 1-based, so we subtract 1! */
			
			/* assign it to the vector */
/*			localResourceInfoList[j] = resourceInfo;
*/		} /* for */

		/* and store that info */
/*		localResourceTable.infoList = localResourceInfoList;
*/		/* Throw away num of resources which appears again */
/*		garbage	= inStream.readShort();
*/		/* finally, store the localResourceTable into the big list */
/*		header.localResourceTable[i] = localResourceTable;
*/	} /* for */
} /* ReadLocalResourceTables */


// resource names
private void ReadResourceNames() throws java.io.IOException
{
	/* Jump to the correct position in the file */
	inStream.seek( header.offsetOfDirectory + header.offsetOfResourceNames );
	
	/* For each of the local resource tables */
	for( int i = 0 ; i < header.localResourceTable.length ; i++ ) {
		/* for each of the resources in the table */
/*		System.out.println("i = " + i + "   header.localResourceTable[i].numberOfResources = " +
				header.localResourceTable[i].numberOfResources +
				" header.localResourceTable[i].resourceInfo.length = " + header.localResourceTable[i].resourceInfo.length );
*/		/* we only read the name if the first char of the resource type is "t", */
		/*	otherwise there isn't a name for that type.	*/
		if ( header.localResourceTable[i].tag.substring(0,1).equals("t") ) {
			for( int j = 0 ; j < header.localResourceTable[i].numberOfResources ; j++ ) {
				/* read in the name and store it */
				header.localResourceTable[i].resourceInfo[j].name = myReadString(inStream);
			} /* for */
		} /* if */
	} /* for */
} /* resource names */


/* global resource table */
/* This info is used by referencing it from the global resource index	*/
/* given in the info of each local resource							*/
private void ReadGlobalResourceTable() throws java.io.IOException
{
/* Var */
//GlobalResourceInfo globalResourceInfo;

	/* Jump to the correct position in the file */
	inStream.seek( header.offsetOfDirectory + header.offsetOfGlobalRsrcTable );

	/* use globalResourceTable */
	/* read the number of global resources */
	header.numberOfGlobalResources = inStream.readInt();
	System.out.println( "Number of global RESOURCES = " + header.numberOfGlobalResources );
	
	header.globalResourceInfo							= new GlobalResourceInfo[header.numberOfGlobalResources];
	/* for each global resource, read its info into the global resource table */
	for( int i = 0 ; i < header.numberOfGlobalResources ; i++ ) {
/*		globalResourceInfo = new GlobalResourceInfo();
*/		header.globalResourceInfo[i]						= new GlobalResourceInfo();
		header.globalResourceInfo[i]	.offsetWithinFile	= inStream.readInt();
		/* this is a little fiddly -- CHECK!! */
		/* I'm not using readShort() because we get 2's complement negative errors if we do. */
		byte	part2									= inStream.readByte();
		byte	part3									= inStream.readByte();
		byte	part1									= inStream.readByte();
		header.globalResourceInfo[i]	.resourceSize		= (int)(Math.pow(2,16)*part1 + Math.pow(2,8)*part2 + part3);
		
/*		header.globalResourceInfo[i]	.resourceSize		= inStream.readShort();
		byte temp										= inStream.readByte();
		int tempint										= temp;
		System.out.println( "temp (byte) = " + temp + "  | tempint (int) = " + tempint + "  |  resourceSize = " + header.globalResourceInfo[i].resourceSize );
		header.globalResourceInfo[i]	.resourceSize		+= (Math.pow(2,16)*tempint);
		System.out.println( "resourceSize now = " + header.globalResourceInfo[i].resourceSize );
*/		System.out.println( "resourceSize = " + header.globalResourceInfo[i].resourceSize );

		header.globalResourceInfo[i]	.resourceFlags		= inStream.readByte();
		header.globalResourceInfo[i]	.unknown			= inStream.readShort();
/*		System.out.println(" unknown = " + header.globalResourceInfo[i].unknown );
*/		
//		header.globalResourceTable[i] = globalResourceInfo;
	} /* for */
	
} /* global resource table */




	
	
	
	// should be called after ReadHeader is called
	public String toString() {
	
		try {
			System.out.println(filename);
			System.out.println(infile);
			System.out.println(header);
/*			return "RivenResourceFile" + "{ " + 
				"filename = " + filename.toString() + 
				", header = " + header.toString() +
				" }";
*/		}
		catch (java.lang.NullPointerException e) {		System.out.println("NullPointerException caught.");	System.out.println(e); }
		//RivenResourceFile{resourceTable={}, infile=filename}
		
		return "hi!";

	/* fuck this shit
		System.out.println( "A" );
		java.util.Hashtable h = new java.util.Hashtable();
		System.out.println("B");
		Class cls = getClass();
		Field[] f = cls.getDeclaredFields();
		System.out.println("C");
		for( int i = 0 ; i < f.length ; i++ ) {
			try { h.put(f[i].getName(), f[i].get(this)); 		System.out.println("Trying to add" + f[i].getName());	System.out.println("D");}
			catch (IllegalAccessException e) {		System.out.println("E");}
			catch (java.lang.NullPointerException e) {		System.out.println("NullPointerException caught.");	System.out.println(e); }
		}
		if  (cls.getSuperclass().getSuperclass() != null) {
			System.out.println("F");
			h.put( "super", super.toString());
			System.out.println("G");
		}
		System.out.println("H");
		return cls.getName() + h;
		*/
	} /* toString */		
	
	
	
	public int numberOfResources() {
		// return the number of resources read in the file
		return 0;
	}
	
	public Hashtable resourceTable() {
		// return the Hashtable containing the table of resources,
		// with the name as key, info object as value
		return new Hashtable();
	}
	
	public String[] resourceNamesList() {
		// return a list of the names of the resources, which
		// are the keys for getting the information out of
		// the resourceTable.
		return new String[100];
	}
	
	
	
	int totalCount = 0;
	/* Can't read more that 500 characters. */
	/* reads from whereever the file pointer currently is at */
	private String myReadString( RandomAccessFile inStream ) throws java.io.IOException
	{
	byte[]		inputBytes	= new byte[500];
	int			i			= 0;
	
		/* read bytes from the in stream until we reach one that is 0 */
		try {	inputBytes[i] = inStream.readByte();	}
		catch (java.io.IOException e) {}
		while ( inputBytes[i] != 0 && i < 500) {
/*			System.out.println("myReadString: i = " + i + "inputBytes[i] = " + inputBytes[i] +
					" --> the string is " + new String(inputBytes) );
*/			i++;
			inputBytes[i] = inStream.readByte();
		}
/*		String temp = "myReadString read <" + new String(inputBytes) + "> which is: ";
		for (int j = 0 ; j < i ; j++) {
			int foo = inputBytes[j];
			temp += foo + "-";
		}
		System.out.println( temp );
*/		
		System.out.println( "Count = " + totalCount++ + " and name is <" + new String(inputBytes) + ">");
		/* now inputBytes contains all the shit we need, and we've read 	*/
		/* everything, including the extra null character.				*/
		if (i==500) {	return "exceeded input buffer size for myReadString";	}
		return new String(inputBytes);
	}
			
	
		/*
	private class localResourceTable {
		private LocalResourceTable[]		localResourceTable;
		//private Vector	localResourceTable;
		public void localResourceTable() {
			localResourceTable = new Vector();
		}
		public LocalResourceTable elementAt( int i ) {
			return (LocalResourceTable) localResourceTable.elementAt( i );
		}
		public void addElement( LocalResourceTable table ) {
			localResourceTable.addElement( table );
		}
		public void setElementAt( LocalResourceTable table, int index ) {
			localResourceTable.setElementAt( table, index );
		}
		public int size() {
			return localResourceTable.size();
		}
	}*/ /* localResourceTable */

	
	
}
