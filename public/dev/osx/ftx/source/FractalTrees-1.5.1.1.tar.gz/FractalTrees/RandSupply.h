//
// RandSupply.h
//
// This class is not copyrighted (Public Domain software)
// However, credit where it is due: originally by Eric Wu <htwunew@yahoo.com>
// It is provided AS IS without any kind of warranty included.
// Portions Copyright (c) 2002 Simon Woodside. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RandSupply : NSObject
{
    FILE * rn;
}


-(unsigned char)getRandomByte;
-(unsigned int)getRandomInt;
-(unsigned int)getRandomIntLessThan:(unsigned int)i;

-(BOOL)getRandomBOOL;
-(float)getRandomFloat;

-(float)getNormalFloat;
-(float)getNormalFloatWithVariance:(float)variance;
-(float)getNormalFloatWithMean:(float)mean variance:(float)variance;


@end
