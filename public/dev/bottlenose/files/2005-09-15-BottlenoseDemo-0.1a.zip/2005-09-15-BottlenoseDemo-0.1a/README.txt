README
for Bottlenose Demo
version 0.1a
2005-09-15

by Simon Woodside
sbwoodside@yahoo.com
http://simonwoodside.com

- read the dev-guide.pdf to find out how to modify BottlenoseDemo.app
- run BottlenoseDemo.app to see the demo in action
- uses XCode 2.1's /Developer/Examples/Quartz/Core Video/LiveVideoMixer
  example, see that app for comparison

Feel free to contact the author with any questions
-- sbwoodside@yahoo.com