/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import "FractalTree.h"
#import "FractalTreeBranch.h"
#import "FractalController.h"
#import "RandSupply.h"

@implementation FractalTree

- (id)init
{
  if( [super init] ) {
    rand = [[RandSupply alloc] init];
    countsLock = [[NSConditionLock alloc] init];
    [countsLock lock];
    NSMutableDictionary * theCounts = [[NSMutableDictionary alloc] init];
    [theCounts setObject:[NSNumber numberWithInt:0] forKey:@"level"];
    [theCounts setObject:[NSNumber numberWithInt:0] forKey:@"node"];
    counts = [NSDictionary dictionaryWithDictionary:theCounts];
    [countsLock unlockWithCondition:0];
    
    // TODO move this
    // Set some reasonable defaults for the initial tree (somewhat pointless with autofit)
    basePoint = NSMakePoint(0, 0);
    baseLength = 200; // TODO calculate it
  }
  return self;
}

- (id)initWithHeight:(int)height controller:(FractalController*)cont;
{
  if( [self init] ) {
    maxHeight = height;
    controller = cont;
  }
  return self;
}

- (void)openLockForUse;
{
  [countsLock unlockWithCondition:1];
}

// This method creates a new tree from scratch with all-new random values
// This method may be running in a separate thread
- (void)createRandomValues:(id)theObject;
{
  [countsLock lock];
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  
  [controller setStatus:@"Randomizing the tree." busy:YES];
  FractalBranch * root;
  int arrayLength = 10;//pow(2, maxHeight + 1) - 1;
  if( branchesArray )
    [branchesArray release];
  branchesArray = [[NSMutableArray arrayWithCapacity:arrayLength] retain];
  root = [[FractalBranch alloc] init];
  [self createRandomByRecursing:root length:1 angle:0 level:0];
  [controller setStatus:@"Done randomizing." busy:NO];
  
  [countsLock unlockWithCondition:1];
  [pool release];
}


// This function only does "real" work if it's a random tree
// Otherwise it just generates a bunch of 1's and 0's
// The rand calls are relatively slow
- (void)createRandomByRecursing:(FractalBranch *)newBranch length:(float)length angle:(float)angle level:(int)level;
{
  [newBranch setAbstractLength:length];
  [newBranch setAbstractAngle:angle];
  [branchesArray addObject:newBranch];
  
  if (level < maxHeight)
  {
    float newLengthLeft, newLengthRight, newAngleLeft, newAngleRight;
    level++;
    [newBranch setLeft:[[FractalBranch alloc] init]];
    [newBranch setRight:[[FractalBranch alloc] init]];
    bool noRandomness = (lengthVariance == 0.0 && angleVariance == 0.0);
    if( !noRandomness )
    {
      newLengthLeft =  [rand getNormalFloatWithMean:1 variance:lengthVariance];
      newLengthRight = [rand getNormalFloatWithMean:1 variance:lengthVariance];
      newAngleLeft =   [rand getNormalFloatWithMean:0 variance:angleVariance];
      newAngleRight =  [rand getNormalFloatWithMean:0 variance:angleVariance];
    } else {
      newLengthLeft = 1.0; newLengthRight = 1.0;
      newAngleLeft = 0.0; newAngleRight = 0.0;
    }
    // Recurse
    [self createRandomByRecursing:[newBranch left] length:newLengthLeft angle:newAngleLeft level:level];
    [self createRandomByRecursing:[newBranch right] length:newLengthRight angle:newAngleRight level:level];
  }
}

// zero-based!!!!
- (FractalBranch *)branchReadyForDrawAtLevel:(int)level index:(int)index;
{
  FractalBranch * parentBranch, * curBranch;
  float branchThick = 0;
  
  if( level == 0 ) {
    // Special handling for the basemost branch
    curBranch = [branchesArray objectAtIndex:0];
    [curBranch setLength:baseLength * [controller lengthFactor] angle:M_PI_2 arcPosition:0.5 basePoint:basePoint];
    [curBranch setEndPoint:NSMakePoint([curBranch basePoint].x, [curBranch basePoint].y + [curBranch length])];
  } else {
    int branchIndex = pow(2, level) - 1  + index;
    int parentIndex = pow(2, level-1) - 1 + floor(index/2);
    parentBranch = [branchesArray objectAtIndex:parentIndex];
    curBranch = [branchesArray objectAtIndex:branchIndex];
    [curBranch setLength: [parentBranch length] * [curBranch abstractLength] * [controller lengthFactor]];
    [curBranch setAngle:[parentBranch angle] + [curBranch abstractAngle]];
    if( index%2 ) { [curBranch setAngle:[curBranch angle] - [controller angleTerm]]; }
    else { [curBranch setAngle:[curBranch angle] + [controller angleTerm]]; }
    // reverse next two lines for an interesting effect
    [curBranch setBasePoint:[parentBranch endPoint]];
    [curBranch setEndPoint:NSMakePoint( [curBranch basePoint].x + ([curBranch length] * cos([curBranch angle])), [curBranch basePoint].y + ([curBranch length] * sin([curBranch angle])) )];
  }
  branchThick = [curBranch length] * [controller thickFactor];
  branchThick -= branchThick * 0.4 * ((level*1.0)/(maxHeight*1.0));
  //  branchThick = 5.0;
  [curBranch setThickness:branchThick];
  return curBranch;
}



// **************************************************************
// API
//

- (void)setVarianceLength:(float)length angle:(float)angle;
{
  lengthVariance = length;
  angleVariance = angle;
}

- (NSConditionLock*)countsLock;
{
  return countsLock;
}

//TODO move this
- (NSPoint)basePoint;
{
  return basePoint;
}
- (void)setBasePoint:(NSPoint)base;
{
  basePoint = base;
}

@end
