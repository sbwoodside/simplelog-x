/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import "ColourController.h"
#import "FractalView.h"
//#import "SSCircularSlider.h"

#define SW_LEAF_THRESHOLD 0.8

@interface ColourController (Private)
- (void)updateColourFromUI;
@end

@implementation ColourController

- (id)init
{
  if( (self = [super init]) )
    height = 1;
  return self;
}

- (void)awakeFromNib;
{
  lastSettings = [[NSMutableDictionary dictionaryWithCapacity:7] retain];
  //[spectrumUI setAngleUnits:SSAnglesAreDegrees];
}

- (void)setHeight:(int)h;
{
  height = h;
}

- (NSColor *)backgroundColour
{
  return [backgroundColourWell color];
}

- (void)updateColourFromUI;
{
  return;
}

- (BOOL)colourUIHasReallyChanged;
{
  return YES;
}

- (void)autoEnableColourControls
{
  [gradientStartColourWell setEnabled:YES]; [gradientEndColourWell setEnabled:YES];
  [backgroundColourWell setEnabled:YES]; //[spectrumUI setEnabled:YES];
  switch( [colourStyleUI indexOfSelectedItem] )
  {
    case SWSpectrumColourStyle:
      [gradientStartColourWell setEnabled:NO]; [gradientEndColourWell setEnabled:NO];
      //[spectrumUI setEnabled:YES];
      break;
    case SWGradientColourStyle:
      //[spectrumUI setEnabled:NO];
      break;
    case SWTwoColourStyle:
      //[spectrumUI setEnabled:NO];
      break;
    case SWOneColourStyle:
      [gradientStartColourWell setEnabled:NO];
      [gradientEndColourWell setEnabled:YES];
      //[spectrumUI setEnabled:NO];
      break;
    default: break;
  }
}

- (NSColor *)getColourForLevel:(int)level withPosition:(float)pos
{
  float alpha = [alphaSlider floatValue];
  float angle, dist;
  NSColor * result = nil;
  switch( [colourStyleUI indexOfSelectedItem] )
  {
    case SWSpectrumColourStyle:
      //[spectrumUI getAngle:&angle andDistance:&dist];
      result = [NSColor colorWithCalibratedHue:fmod(pos + (angle/360.0), 1.0) saturation:1.0 brightness:1.0 alpha:alpha];
      break;
    case SWGradientColourStyle:
      result = [[gradientStartColourWell color] blendedColorWithFraction:(level/height) ofColor:[gradientEndColourWell color]];
      if( result )
        result = [[[gradientStartColourWell color] blendedColorWithFraction:(1.0*level/(height)) ofColor:[gradientEndColourWell color]] colorWithAlphaComponent:alpha];
      break;
    case SWTwoColourStyle:
      if( (1.0*level)/(height-1) > SW_LEAF_THRESHOLD )
        result = [[gradientEndColourWell color] colorWithAlphaComponent:alpha];
      else
        result = [[gradientStartColourWell color] colorWithAlphaComponent:alpha];
      break;
    case SWOneColourStyle:
      result = [[monochromeColourWell color] colorWithAlphaComponent:alpha];
      break;
  }
  if( result )
    return result;
  else
    return [NSColor redColor]; // some kind of error :-)
}

@end
