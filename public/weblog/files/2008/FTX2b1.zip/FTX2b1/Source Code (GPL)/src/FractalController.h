/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import <AppKit/AppKit.h>

#define SW_NATURAL_RANDOM_NUMBER 0.002
#define SW_WILD_RANDOM_NUMBER 0.006
#define SW_CRAZY_RANDOM_NUMBER 0.0125
#define SW_TOOMUCH_RANDOM_NUMBER 1.0

@class ColourController, FractalView, FractalTree;

//info window
typedef enum {
  SWDepthField = 0,
  SWAngleDeltaField = 1,
  SWGrowthFactorField = 2,
  SWAngleRandomnessField = 3,
  SWLengthRandomnessField = 4,
  SWThicknessField = 5,
  SWZoomFactorField = 6,
} SWInformationField;

//draw style
typedef enum {
  NotRandomStyle = 0,
  NaturalRandomStyle = 1,
  WildRandomStyle = 2,
  CrazyRandomStyle = 3,
  TooMuchRandomStyle = 4,
} RandomStyle;

@interface FractalController : NSObject
{
  IBOutlet id indicator;
  
  IBOutlet id view;
  IBOutlet id colourController;
  IBOutlet id colourConfigureWindow;
  IBOutlet id informationForm;
  
  IBOutlet id heightDisplay;
  IBOutlet id statusDisplay;
  IBOutlet id fpsDisplay;
  
  IBOutlet id colourStyleUI;
  IBOutlet id randomStyleUI;
  IBOutlet id lengthVarianceUI;
  IBOutlet id angleVarianceUI;
  IBOutlet id lengthUI;
  IBOutlet id angleUI;
  IBOutlet id drawStyleUI;
  IBOutlet id thickUI;
  IBOutlet id heightUI;
  
  FractalTree * tree;
  NSMutableDictionary * lastSettings;
  float lastColourValue;
  BOOL heightAtMax;
  BOOL mRecreateRandom;
}

- (void)finishedDrawingCallback;

- (void)setStatus:(NSString *)status;
- (void)setStatus:(NSString*)statusMsg busy:(BOOL)busy;

- (IBAction)open:(id)sender;
- (IBAction)save:(id)sender;

- (IBAction)kidpix:(id)sender;

- (IBAction)randomize:(id)sender;

// updates from the UI
- (IBAction)drawUIHasChanged:(id)sender;
- (IBAction)colourUIHasChanged:(id)sender;
- (IBAction)randomUIHasChanged:(id)sender;

// Data Export
- (IBAction)copy:(id)sender;
- (IBAction)export:(id)sender;

- (int)drawStyle;
- (float)lengthFactor;
- (float)angleTerm;
- (float)thickFactor;
- (int)height;

- (BOOL)drawUIHasReallyChanged;
- (void)copyUISettingsToInternal;
@end
