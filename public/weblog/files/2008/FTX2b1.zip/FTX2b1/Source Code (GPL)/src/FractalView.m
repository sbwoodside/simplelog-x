/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import "FractalView.h"
#import "FractalTree.h"
#import "FractalTreeBranch.h"
#import "ColourController.h"
#import "FractalController.h"

#define INITIAL_LINE_CAP_STYLE NSSquareLineCapStyle
// NSRoundLineCapStyle NSSquareLineCapStyle NSButtLineCapStyle

@interface FractalView(Private)
- (void)drawTheTree:(FractalTree*)tree;
- (void)setupPrint;

- (NSRect)padRect:(NSRect)rect withPadding:(float)padding;
- (NSPoint)subtractPoint:(NSPoint)p1 fromPoint:(NSPoint)p2;
- (NSPoint)addPoint:(NSPoint)p1 toPoint:(NSPoint)p2;
- (NSString*)theTime;
- (void)drawBranch:(FractalBranch *)branch level:(int)level;
@end

@implementation FractalView

- (id) initWithFrame:(NSRect)frame
{
  if( [super initWithFrame:frame] ) {
    runAutofit = YES;
    [NSBezierPath setDefaultLineCapStyle:INITIAL_LINE_CAP_STYLE];
  }
  return self;
}

- (void) awakeFromNib;
{
  [self setupPrint];
  newRect = NSMakeRect(0,0,400,400);
  NSImage * icon = [NSApp applicationIconImage];
  [self setImage:icon];
}


#pragma mark -


- (void)drawRect:(NSRect)rect;
{
  NSLog(@"drawRect");
  [[NSColor blackColor] set];
  NSRectFill(rect);
  [super drawRect:rect];
}


- (void)drawTree:(FractalTree*)tree;
{
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  NSLog(@"waiting to draw the tree");
  [[tree countsLock] lockWhenCondition:1];
  [controller setStatus:@"Starting to draw tree to image." busy:YES];
  
  NSSize useSize = NSMakeSize(newRect.size.width+100, newRect.size.height+100);
  NSImage * imageBuf = [[NSImage alloc] initWithSize:useSize];
  [imageBuf autorelease];
  //  [imageBuf setBackgroundColor:[NSColor redColor]];  //seems to do nothing
  NSPoint base = NSMakePoint([imageBuf size].width/2,0);
  [tree setBasePoint:base];
  newRect = NSMakeRect(0,0,0,0);
  
  [imageBuf lockFocus];//];
  [self drawTheTree:tree];
  [imageBuf unlockFocus];
  [self setImage:imageBuf];
  
  [[tree countsLock] unlock];
  [controller setStatus:@"Finished drawing tree to image." busy:NO];
  
  [controller finishedDrawingCallback];
  [pool release];
}

// Draw the tree with a nonrecursive algorithm
- (void)drawTheTree:(FractalTree*)tree;
{
  int level, index;
  FractalBranch * curBranch;
  curBranch = [tree branchReadyForDrawAtLevel:0 index:0];
  [self drawBranch:curBranch level:0];
  
  // linear loop through levels, indices, and then drawBranch
  for( level=1; level<[controller height]; level++ ) {
    for( index=0; index<pow(2,level); index++ ) {
      curBranch = [tree branchReadyForDrawAtLevel:level index:index];
      float arcPos = [FractalBranch arcPositionForIndex:index maxLevel:level];
      [curBranch setArcPosition:arcPos];
      [self drawBranch:curBranch level:level];
    }
  }
}

- (void)drawBranch:(FractalBranch *)branch level:(int)level;
{
  [[colour getColourForLevel:level withPosition:[branch arcPosition]] set];
  [NSBezierPath setDefaultLineWidth:[branch thickness]];
  [NSBezierPath strokeLineFromPoint:[branch basePoint] toPoint:[branch endPoint]];
  newRect = NSUnionRect( newRect, [branch normalizedRect] );
}

#pragma mark -


// Clipboard
- (IBAction)copy
{
  NSImage * image = [self image];
  NSPasteboard * pboard = [NSPasteboard generalPasteboard];
  [pboard declareTypes:[NSArray arrayWithObject:NSTIFFPboardType] owner:self];
  if( ![pboard setData:[image TIFFRepresentation] forType:NSTIFFPboardType] )
    NSLog(@"setting TIFF rep on pasteboard FAILED");
}

// Export to TIFF
- (IBAction)export
{
  NSSavePanel * panel = [NSSavePanel savePanel];
  [panel setRequiredFileType:@"tiff"];
  [panel beginSheetForDirectory:nil file:@"Untitled.tiff" modalForWindow:[self window] modalDelegate:self didEndSelector:@selector(exportPanelDidEnd: returnCode: contextInfo:) contextInfo:nil];
}

- (void)exportPanelDidEnd:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo
{
  NSSavePanel * panel;
  panel = (NSSavePanel *)sheet;
  if( returnCode == NSOKButton ) {
    NSImage * image = [self image];
    NSData * data = [image TIFFRepresentation];
    if( ![data writeToFile:[panel filename] atomically:YES] )
      NSLog(@"writing TIFF rep to file FAILED");
  }
}

- (void)setupPrint;
{
  NSPrintInfo * sharedPrintInfo;
  
  sharedPrintInfo = [NSPrintInfo sharedPrintInfo];
  [sharedPrintInfo setHorizontalPagination:NSFitPagination];
  [sharedPrintInfo setVerticalPagination:NSFitPagination];
  [sharedPrintInfo setHorizontallyCentered:YES];
  [sharedPrintInfo setVerticallyCentered:YES];
  [NSPrintInfo setSharedPrintInfo:sharedPrintInfo];
}




#pragma mark -


// Various NSRect utility functions
- (NSRect)padRect:(NSRect)rect withPadding:(float)padding;
{
  NSRect result;
  result.origin.x = rect.origin.x - padding;
  result.origin.y = rect.origin.y - padding;
  result.size.width = rect.size.width + 2 * padding;
  result.size.height = rect.size.height + 2 * padding;
  return result;
}

// p2 - p1
- (NSPoint)subtractPoint:(NSPoint)p1 fromPoint:(NSPoint)p2;
{
  NSPoint point = NSMakePoint( p2.x - p1.x, p2.y - p1.y );
  return point;
}
- (NSPoint)addPoint:(NSPoint)p1 toPoint:(NSPoint)p2;
{
  NSPoint point = NSMakePoint( p2.x + p1.x, p2.y + p1.y );
  return point;
}


#pragma mark -

// Superclass Overrides
//
- (void)dealloc
{
  [super dealloc];
}
- (BOOL)isOpaque
{
  return YES;
}
- (BOOL)acceptsFirstResponder
{
  return YES;
}


@end