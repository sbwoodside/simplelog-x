//
//  FractalDraw.m
//  FractalTrees
//
//  Created by Simon Woodside on Thurs May 30 2002.
//  Copyright (c) 2002 Simon Woodside. All rights reserved.
//

#import "FractalDraw.h"
#import "FractalTree.h"
#import "FractalTreeBranch.h"
#import "ColourController.h"
#import "FractalController.h"

#define SW_INITIAL_LINE_CAP_STYLE NSSquareLineCapStyle
// NSRoundLineCapStyle NSSquareLineCapStyle NSButtLineCapStyle
#define SW_SCALE_TO_FIT_PADDING 0
#define SW_ABORT_INTERVAL 0.05
#define SW_FLUSH_INTERVAL 0.25

@interface FractalDraw(Private)
- (void)drawTheTree:(FractalTree*)tree;
- (void)resizeImageBuf;

- (NSRect)padRect:(NSRect)rect withPadding:(float)padding;
- (NSRect)fitRectToAspectRatio:(NSRect)rect;
- (NSPoint)subtractPoint:(NSPoint)p1 fromPoint:(NSPoint)p2;
- (NSPoint)addPoint:(NSPoint)p1 toPoint:(NSPoint)p2;
- (NSString*)theTime;
- (void)autofitBounds;
- (void)drawBranch:(FractalBranch *)branch level:(int)level;
- (void)setAbortForChangesIfNecessary;
- (void)flushDrawingIfNecessary:(FractalBranch *)branch;
- (void)flushDrawing;
- (void)setupPrint;
- (BOOL)needAutofit;
- (void)prepareToDrawTree;
@end

@implementation FractalDraw

- (id)initWithFrame:(NSRect)frame
{
  if( [super initWithFrame:frame] ) {
    runAutofit = YES;
    practiceDraw = YES;
    [NSBezierPath setDefaultLineCapStyle:SW_INITIAL_LINE_CAP_STYLE];
  }
  return self;
}

- (void)awakeFromNib;
{
  [self setupPrint];
  NSSize size = NSMakeSize(400.0,400.0);//[self frame].size;
  imageBuf = [[NSImage alloc] initWithSize:size];
  [imageBuf retain];
  [self setImage:imageBuf];
  //  [self setImageScaling:NSScaleToFit];
}


#pragma mark -


- (void)drawRect:(NSRect)rect;
{
  NSLog(@"drawRect");
  //  [self lockFocus];
  [self setImage:imageBuf];
  [super drawRect:rect];
  //  [imageBuf compositeToPoint:[self bounds].origin operation:NSCompositeCopy];
  //  [self unlockFocus];
}


- (void)drawTree:(FractalTree*)tree;
{
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  NSLog(@"waiting to draw the tree");
  [[tree countsLock] lockWhenCondition:1];
  NSLog(@"starting to draw tree to image");
  [imageBuf lockFocus];

/*  practiceDraw = YES;
  [self drawTheTree:tree];

  [imageBuf release];
  NSSize size = NSMakeSize(400.0,400.0);//[self frame].size;
  imageBuf = [[NSImage alloc] initWithSize:size];
  [imageBuf retain];
  [self setImage:imageBuf];*/

  practiceDraw = NO;
  [self drawTheTree:tree];

  [imageBuf unlockFocus];
  [[tree countsLock] unlock];
  NSLog(@"finished to drawing tree to image");
  [controller finishedDrawingCallback];
  [pool release];
}

// Draw the tree with a nonrecursive algorithm
- (void)drawTheTree:(FractalTree*)tree;
{
  int level, index;
  FractalBranch * curBranch;

  if( practiceDraw == NO )
    [imageBuf setBackgroundColor:[NSColor redColor]];

  NSPoint base = NSMakePoint([imageBuf size].width/2,[imageBuf size].height/9);
  [tree setBasePoint:base];
  float length = [imageBuf size].height/3;
  [tree setBaseLength:length];
  curBranch = [tree branchReadyForDrawAtLevel:0 index:0];
  //  if( runAutofit) { newRect = [curBranch normalizedRect]; }
  [self drawBranch:curBranch level:0];
  //  if( abortForChanges ) { NSLog(@" ABORTED-LEVEL0 }");  return; }

  // linear loop through levels, indices, and then drawBranch
  for( level=1; level<[controller height]; level++ ) {
    for( index=0; index<pow(2,level); index++ ) {
      curBranch = [tree branchReadyForDrawAtLevel:level index:index];
      float arcPos = [FractalBranch arcPositionForIndex:index maxLevel:level];
      [curBranch setArcPosition:arcPos];
      [self drawBranch:curBranch level:level];
      //      if( abortForChanges ) { NSLog(@" ABORTED-LEVEL+ } ");  return; }
    }
  }
  // if abort happened, won't get here
  NSLog(@"completed draw without abort");
}

- (void)drawBranch:(FractalBranch *)branch level:(int)level;
{
  if( practiceDraw )
    newRect = NSUnionRect( newRect, [branch normalizedRect] );
  else {
    [[colour getColourForLevel:level withPosition:[branch arcPosition]] set];
    [NSBezierPath setDefaultLineWidth:[branch thickness]];
    [NSBezierPath strokeLineFromPoint:[branch basePoint] toPoint:[branch endPoint]];
  }
}

#pragma mark -

- (BOOL)needAutofit;
{
  if( NSEqualRects([self bounds], [self fitRectToAspectRatio:newRect]) )
  { return NO; }
  else { return YES; }
}

// ****************************************
// Maximize tree size within viewable area
- (void)autofitBounds;
{
  newRect = [self fitRectToAspectRatio:newRect];
  [self setBounds:newRect];
}

// ****************************************
// changes by user might obselete current draw
- (void)setAbortForChangesIfNecessary;
{
  // only abort is sufficient time has passed
  if( fabs([lastAbortCheckDate timeIntervalSinceNow]) > SW_ABORT_INTERVAL ) {
    NSEvent * mouseEvent = [NSApp nextEventMatchingMask:NSMouseMovedMask
                                              untilDate:nil
                                                 inMode:NSEventTrackingRunLoopMode
                                                dequeue:YES];
    lastAbortCheckDate = [[NSDate dateWithTimeIntervalSinceNow:0] retain];
    // only abort if a mouse MOVED event has occurred
    if( mouseEvent ) {
      abortForChanges = YES;
      [controller copyUISettingsToInternal];
      return;
    }
  }
}

// ****************************************
- (void)flushDrawingIfNecessary:(FractalBranch *)branch;
{
  switch (drawFlushFreq)
  {
    case EveryBranchFrequency:
      [self flushDrawing];
      break;
    case EveryLevelFrequency:
      if( [branch arcPosition] == 0 ) {
        [self flushDrawing];
      }
      break;
    case TimedFrequency:
      if( fabs([lastFlushDate timeIntervalSinceNow]) > SW_FLUSH_INTERVAL ) {
        [self flushDrawing];
      }
      break;
    default: break;
  }
}

- (void)flushDrawing;
{
  [[self window] enableFlushWindow];
  //  NSLog(@"***** A isFlushWindowDisabled=%i\n", [[self window] isFlushWindowDisabled] );
  [[NSGraphicsContext currentContext] flushGraphics];
  [[self window] flushWindow];
  lastFlushDate = [[NSDate dateWithTimeIntervalSinceNow:0] retain];
  [[self window] disableFlushWindow];
}



// ****************************************
// ****************************************
// ****************************************
// API
/*- (void)setNeedsDisplay:(BOOL)display withAutofit:(BOOL)autofit;
{
  runAutofit = autofit;
  [self setNeedsDisplay:display];
}*/
- (void)setDrawFlushFrequency:(DrawFlushFrequency)freq;
{ drawFlushFreq = freq; }
- (BOOL)abortedLastDrawForChanges;
{ return abortedLastDrawForChanges; }


  // ****************************************
  // ****************************************
  // ****************************************
  // Clipboard
- (IBAction)copy
{
  // workaround: this only works if baseLength is set to a small number
  // basically this scheme fails if "pixelSize" (i.e. the ratio between
  // bounds and frame) ever exceeds 1.0
  NSRect copyRect = [self frame];
  copyRect.origin = [self bounds].origin;

  NSLog(@"copy: copyRect = %s\n", [NSStringFromRect(copyRect) cString] );

  NSImage * image = [[NSImage alloc] initWithData:
    [self dataWithPDFInsideRect:copyRect]];

  NSPasteboard * pboard = [NSPasteboard generalPasteboard];
  [pboard declareTypes:[NSArray arrayWithObject:NSTIFFPboardType] owner:self];
  if( ![pboard setData:[image TIFFRepresentation] forType:NSTIFFPboardType] )
  {
    NSBeep();	// complain
  }
}

// **************************************************************
// Export to TIFF
- (IBAction)export
{
  NSSavePanel * panel = [NSSavePanel savePanel];
  [panel setRequiredFileType:@"tiff"];
  [panel beginSheetForDirectory:nil file:@"Untitled.tiff"
                 modalForWindow:[self window] modalDelegate:self
                 didEndSelector:@selector(exportPanelDidEnd: returnCode: contextInfo:)
                    contextInfo:nil];
}
// **************************************************************
// Callback
//
- (void)exportPanelDidEnd:(NSWindow *)sheet
               returnCode:(int)returnCode
              contextInfo:(void *)contextInfo
{
  NSSavePanel * panel;
  panel = (NSSavePanel *)sheet;
  if( returnCode == NSOKButton ) {
    NSRect copyRect = [self frame];
    copyRect.origin = [self bounds].origin;
    NSImage * image = [[NSImage alloc] initWithData:[self dataWithPDFInsideRect:copyRect]];
    NSData * data = [image TIFFRepresentation];
    if( ! [data writeToFile:[panel filename] atomically:YES] )
    { NSBeep(); }
  }
}


// Various NSRect utility functions
- (NSRect)padRect:(NSRect)rect withPadding:(float)padding;
{
  // Make a copy
  NSRect result;
  result.origin.x = rect.origin.x - padding;
  result.origin.y = rect.origin.y - padding;
  result.size.width = rect.size.width + 2 * padding;
  result.size.height = rect.size.height + 2 * padding;
  return result;
}

- (NSRect)fitRectToAspectRatio:(NSRect)rect
{
  float heightShouldBe;
  float widthShouldBe;
  float difference;
  NSRect paddedRect;
  //= [self padRect:rect withPadding:[tree baseLength]*tree->lengthFactor*tree->thickFactor/1.75];
  // the 1.75 is a total hack. the real problem is that we need to pad
  // each time we update the autofit rect. then use 2.0 here should be right.
  NSRect result = NSOffsetRect(paddedRect, 0.0, 0.0);
  // cheap hack cause I don't know how to properly copy a struct
  // fix the aspect ratio by expanding the rect
  heightShouldBe = paddedRect.size.width / aspectRatio;
  widthShouldBe = paddedRect.size.height * aspectRatio;
  if( heightShouldBe >= paddedRect.size.height )
  {
    difference = (heightShouldBe - paddedRect.size.height);
    result.size.height += difference;
    result.origin.y -= difference/2.0;
  } else {
    difference = (widthShouldBe - paddedRect.size.width);
    result.size.width += difference;
    result.origin.x -= difference/2.0;
  }
  //    NSLog(@"SWFitRectToAspectRatio: newRect = %s\n",
  //           [NSStringFromRect(result) cString]);
  return result;
}


// p2 - p1
- (NSPoint)subtractPoint:(NSPoint)p1 fromPoint:(NSPoint)p2;
{ return NSMakePoint( p2.x - p1.x, p2.y - p1.y ); }
- (NSPoint)addPoint:(NSPoint)p1 toPoint:(NSPoint)p2;
{   return NSMakePoint( p2.x + p1.x, p2.y + p1.y ); }


- (void)setupPrint;
{
  NSPrintInfo * sharedPrintInfo;

  sharedPrintInfo = [NSPrintInfo sharedPrintInfo];
  [sharedPrintInfo setHorizontalPagination:NSFitPagination];
  [sharedPrintInfo setVerticalPagination:NSFitPagination];
  [sharedPrintInfo setHorizontallyCentered:YES];
  [sharedPrintInfo setVerticallyCentered:YES];
  [NSPrintInfo setSharedPrintInfo:sharedPrintInfo];
}


// ****************************************
// ****************************************
// ****************************************
// Superclass Overrides
//
- (void)dealloc
{
  [super dealloc];
}
- (BOOL)isOpaque
{
  return YES;
}
- (BOOL)acceptsFirstResponder
{
  return YES;
}

- (NSString*)theTime;
{
  NSDate * nowTime = [NSDate dateWithTimeIntervalSinceNow:0];
  return [nowTime descriptionWithCalendarFormat:@"%M:%S.%F"
                                       timeZone:nil
                                         locale:nil];
}

/*- (void)prepareToDrawTree;
{
  drawFlushFreq = [controller drawStyle];
  lastFlushDate = [[NSDate dateWithTimeIntervalSinceNow:0] retain];
  lastAbortCheckDate = [[NSDate dateWithTimeIntervalSinceNow:0] retain];
  abortForChanges = NO;
  abortedLastDrawForChanges = NO;

  aspectRatio = [imageBuf size].width / [imageBuf size].height;
  pixelSize = 1.0;//[self bounds].size.height / [self frame].size.height;
}*/



@end