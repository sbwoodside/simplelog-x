//
//  FractalDraw.h
//  FractalTrees
//
//  Created by Simon Woodside on Thurs May 30 2002.
//  Copyright (c) 2002 Simon Woodside. All rights reserved.
//

#import <AppKit/AppKit.h>

@class FractalBranch, FractalTree, ColourController, FractalController;

typedef enum {
    NeverFrequency = 0,
    EveryBranchFrequency = 1,
    EveryLevelFrequency = 2,
    TimedFrequency = 3
} DrawFlushFrequency;

@interface FractalDraw : NSObject
{
    BOOL practiceDraw;
    DrawFlushFrequency drawFlushFreq;
    NSRect newRect;
    float aspectRatio;
    float pixelSize;
    BOOL abortForChanges;
    NSDate * lastFlushDate;
    NSDate * lastAbortCheckDate;
    BOOL runAutofit;
    BOOL abortedLastDrawForChanges;
}

- (id)initWithFrame:(NSRect)frame;
- (void)drawRect:(NSRect)rect;
- (void)drawTree:(FractalTree*)tree;

- (void)copy;
- (void)export;
- (void)exportPanelDidEnd:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void  *)contextInfo;

// Display methods
//- (void)setNeedsDisplay:(BOOL)display withAutofit:(BOOL)autofit;

// API
- (BOOL)abortedLastDrawForChanges;

@end
