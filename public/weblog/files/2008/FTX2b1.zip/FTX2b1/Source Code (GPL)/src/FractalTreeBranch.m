/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import "FractalTreeBranch.h"

@interface FractalBranch (Private)
NSRect SWMakeNormalizedNonEmptyRect( NSRect rect );
@end

@implementation FractalBranch

- (id)init
{
  [super init];
  abstractLength = 1.0;
  abstractAngle = 0.0;
  return self;
}

- (FractalBranch*)left;
{
  return left;
}
- (FractalBranch*)right;
{
  return right;
}
- (void)setLeft:(FractalBranch*)newLeft;
{
  if( left )
    [left release];
  left = [newLeft retain];
}
- (void)setRight:(FractalBranch*)newRight;
{
  if( right )
    [right release];
  right = [newRight retain];
}


- (float)abstractLength;
{   return abstractLength; }
- (float)abstractAngle;
{   return abstractAngle; }
- (NSPoint)basePoint;
{ return basePoint; }
- (NSPoint)endPoint;
{ return endPoint; }
- (float)length;
{ return length; }
- (float)angle;
{ return angle; }
- (float)arcPosition;
{ return arcPosition; }
- (float)thickness;
{ return thickness; }
- (void)setAbstractLength:(float)newLength;
{
  abstractLength = newLength;
}
- (void)setAbstractAngle:(float)newAngle;
{
  abstractAngle = newAngle;
}
- (void)setLength:(float)newLength;
{
  length = newLength;
}
- (void)setAngle:(float)newAngle;
{
  angle = newAngle;
}
- (void)setBasePoint:(NSPoint)newBase;
{
  basePoint = newBase;
}
- (void)setEndPoint:(NSPoint)newEnd;
{
  endPoint = newEnd;
}
- (void)setThickness:(float)newThick;
{
  thickness = newThick;
}
- (void)setArcPosition:(float)arc;
{
  arcPosition = arc;
}
- (void)setLength:(float)newLength angle:(float)newAngle arcPosition:(float)newPosition basePoint:(NSPoint)newBase;
{
  length = newLength;
  angle = newAngle;
  arcPosition = newPosition;
  basePoint = newBase;
}


// **************************************************************
// Sets the position between 0 and 1 on this level (0 is leftmost branch,
// 1 is rightmost branch)
//
+ (float)arcPositionForIndex:(int)index maxLevel:(int)max;
{
  return (index+0.5)/pow(2,max);
}

- (NSRect)normalizedRect;
{
  NSRect result;
  result = SWMakeNormalizedNonEmptyRect(NSMakeRect( basePoint.x, basePoint.y, endPoint.x - basePoint.x, endPoint.y - basePoint.y ));
  return result;
}

NSRect SWMakeNormalizedNonEmptyRect( NSRect rect )
{
  // no negative sizes
  if( rect.size.width < 0 ) {
    rect.origin.x += 	rect.size.width;		// subtracts actually
    rect.size.width -= 	2.0 * rect.size.width;		// flips the sign
  }
  if( rect.size.height < 0 ) {
    rect.origin.y += 	rect.size.height;
    rect.size.height -= 	2.0 * rect.size.height;
  }
  if( rect.size.width == 0 ) { rect.size.width = 0.1; }	// not quite empty
  if( rect.size.height == 0 ) { rect.size.height = 0.1; }
  return rect;
}

@end
