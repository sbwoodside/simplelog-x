/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import "FractalController.h"

#import "FractalView.h"
#import "ColourController.h"
#import "FractalTree.h"


@interface FractalController(Private)
- (void)controlNewTree;
- (void)copyRandomUISettingsToInternal;
- (void)copyInternalSettingsToUI;
- (void)updateInformationPanel;
- (void)copyHeightUIToInternal;
- (void)recreateRandom;
- (void)drawTheSucker;
@end

@implementation FractalController

// *******************************************
// Init
//
- (id)init
{
  if( (self = [super init]) ) {
    heightAtMax = NO;
    mRecreateRandom = YES;
  }
  return self;
}

- (void)awakeFromNib;
{
  if( indicator ) {
    [indicator setUsesThreadedAnimation:YES];
    //[indicator setStyle:NSProgressIndicatorSpinningStyle];
    //[indicator setDisplayedWhenStopped:NO];
  }
  lastSettings = [[NSMutableDictionary dictionaryWithCapacity:5] retain];
  NSLog(@"controller: awakeFromNib finished.\n");
  [self getGoing];
}

- (void)setStatus:(NSString *)status;
{
  NSLog(status);
  [statusDisplay setObjectValue:status];
  [statusDisplay setNeedsDisplay:YES];
}

- (void)setSpinner:(BOOL)set;
{
  if( indicator ) {
    if( set) { [indicator startAnimation:self]; }
    else { [indicator stopAnimation:self]; }
  }
}

- (void)setStatus:(NSString*)statusMsg busy:(BOOL)busy;
{
  [self setStatus:statusMsg];
  [self setSpinner:busy];
}

#pragma mark -

- (IBAction)kidpix:(id)sender;
{
  if( mRecreateRandom ) {
    [self recreateRandom];
  }
  [self drawTheSucker];
  ///[NSThread detachNewThreadSelector:@selector(drawTree:) toTarget:view withObject:tree];
}

- (void)finishedDrawingCallback;
{
  [view setNeedsDisplay:YES];
}

- (void)getGoing;
{
  [self copyUISettingsToInternal];
  [self copyInternalSettingsToUI];
  [self recreateRandom];
  [self drawTheSucker];
}
- (void)drawTheSucker;
{
  [NSThread detachNewThreadSelector:@selector(drawTree:) toTarget:view withObject:tree];  
}


#pragma mark -


- (IBAction)drawUIHasChanged:(id)sender;
{
  [self copyUISettingsToInternal];
  [self copyInternalSettingsToUI];
  [self drawTheSucker];
  //[view setNeedsDisplay:YES withAutofit:YES];
}

- (IBAction)colourUIHasChanged:(id)sender;
{
  [self copyUISettingsToInternal];
  [self copyInternalSettingsToUI];
  [self drawTheSucker];
  //  [colourController autoEnableColourControls];
  //  [self updateInformationPanel];
}


- (IBAction)randomUIHasChanged:(id)sender;
{
  [self copyRandomUISettingsToInternal];
  [self copyInternalSettingsToUI];
  [self recreateRandom];
  [self drawTheSucker];
}

- (IBAction)randomize:(id)sender;
{
  [self recreateRandom];
  [self drawTheSucker];
}

- (void)recreateRandom;
{
  if( tree )
    [tree release];
  tree = [[FractalTree alloc] initWithHeight:[heightUI maxValue] controller:self];
  [self copyRandomUISettingsToInternal];
  [tree setVarianceLength:[lengthVarianceUI floatValue] angle:[angleVarianceUI floatValue]];
  
  [NSThread detachNewThreadSelector:@selector(createRandomValues:) toTarget:tree withObject:nil];
  mRecreateRandom = NO;
}  

#pragma mark -

/*- (BOOL)permitDraw;
 {
 if( [self drawUIHasReallyChanged] ) { return YES; }
 if( [colourController colourUIHasReallyChanged] ) { return YES; }
 return NO;
 }*/

- (void)setFPS:(float)fps;
{
  [fpsDisplay setStringValue:[NSString stringWithFormat:@"%f fps", fps]];
}



#pragma mark -

- (BOOL)drawUIHasReallyChanged;
{
  // the ui will say they "changed" even if the user
  // just clicks or lets go. this checks the values
  // Also checks the view, if it aborted the last draw
  // for an event we must send it another one or else
  // it will stop in mid-draw and look bad
  if( [(NSNumber *)[lastSettings objectForKey:@"length"] compare:[lengthUI objectValue]] ||
     [(NSNumber *)[lastSettings objectForKey:@"angle"]  compare:[angleUI objectValue]] ||
     [(NSNumber *)[lastSettings objectForKey:@"drawStyle"] compare:[drawStyleUI objectValue]] ||
     [(NSNumber *)[lastSettings objectForKey:@"thick"]  compare:[thickUI objectValue]] ||
     [(NSNumber *)[lastSettings objectForKey:@"height"] compare:[heightUI objectValue]]
     ) 
  { return YES; }
  else { return NO; }
}


- (void)copyUISettingsToInternal;
{
  [lastSettings setObject:[lengthUI objectValue] forKey:@"length"];
  [lastSettings setObject:[angleUI objectValue] forKey:@"angle"];
  [lastSettings setObject:[thickUI objectValue] forKey:@"thick"];
  [lastSettings setObject:[drawStyleUI objectValue] forKey:@"drawStyle"];
  [lastSettings setObject:[heightUI objectValue] forKey:@"height"];
  [colourController setHeight:[heightUI intValue]];
  //TODO copy UI settings to colour UI
  if( [heightUI intValue] == [heightUI maxValue] )
    heightAtMax = YES;
  else
    heightAtMax = NO;
}


- (void)copyInternalSettingsToUI;
{
  [lengthUI setObjectValue:[lastSettings objectForKey:@"length"]];
  [angleUI  setObjectValue:[lastSettings objectForKey:@"angle"]];
  [thickUI  setObjectValue:[lastSettings objectForKey:@"thick"]];
  [drawStyleUI setObjectValue:[lastSettings objectForKey:@"drawStyle"]];
  [heightUI setObjectValue:[lastSettings objectForKey:@"height"]];
  [heightDisplay setObjectValue:[lastSettings objectForKey:@"height"]];
  [randomStyleUI setObjectValue:[lastSettings objectForKey:@"randomStyle"]];
  [[informationForm cellAtIndex:SWDepthField] setIntValue:[heightUI intValue]];
  [[informationForm cellAtIndex:SWAngleDeltaField] setFloatValue:[angleUI floatValue]];
  [[informationForm cellAtIndex:SWGrowthFactorField] setFloatValue:[lengthUI floatValue]];
  [[informationForm cellAtIndex:SWAngleRandomnessField] setFloatValue:[angleVarianceUI floatValue]];
  [[informationForm cellAtIndex:SWLengthRandomnessField] setFloatValue:[lengthVarianceUI floatValue]];
  [[informationForm cellAtIndex:SWThicknessField] setFloatValue:[thickUI floatValue]];
  //  [self copyHeightUIToInternal];
  //  [self copyRandomUISettingsToInternal];
}

- (void)copyRandomUISettingsToInternal;
{
  BOOL useRandom = YES;
  [lastSettings setObject:[randomStyleUI objectValue] forKey:@"randomStyle"];
  switch( [randomStyleUI intValue] )
  {
    case NotRandomStyle:
      [lengthVarianceUI setFloatValue:0.0];
      [angleVarianceUI setFloatValue:0.0];
      useRandom = NO;
      break;
    case NaturalRandomStyle:
      [lengthVarianceUI setFloatValue:SW_NATURAL_RANDOM_NUMBER];
      [angleVarianceUI setFloatValue:SW_NATURAL_RANDOM_NUMBER];
      break;
    case WildRandomStyle:
      [lengthVarianceUI setFloatValue:SW_WILD_RANDOM_NUMBER];
      [angleVarianceUI setFloatValue:SW_WILD_RANDOM_NUMBER];
      break;
    case CrazyRandomStyle:
      [lengthVarianceUI setFloatValue:SW_CRAZY_RANDOM_NUMBER];
      [angleVarianceUI setFloatValue:SW_CRAZY_RANDOM_NUMBER];
      break;
    case TooMuchRandomStyle:
      [lengthVarianceUI setFloatValue:SW_TOOMUCH_RANDOM_NUMBER];
      [angleVarianceUI setFloatValue:SW_TOOMUCH_RANDOM_NUMBER];
      break;
  }
  [lengthVarianceUI setEnabled:useRandom];
  [angleVarianceUI setEnabled:useRandom];
}



#pragma mark -

// **************************************************************
// Data export
//
- (IBAction)copy:(id)sender;
{
  [(FractalView*)view copy];
}
- (IBAction)export:(id)sender;
{
  [view export];
}

- (IBAction)open:(id)sender;
{
  NSOpenPanel *oPanel = [NSOpenPanel openPanel];
  [oPanel setAllowsMultipleSelection:NO];
  [oPanel beginSheetForDirectory:nil file:nil types:[NSArray arrayWithObject:@"ftx"] modalForWindow:[view window] modalDelegate:self didEndSelector:@selector(openPanelDidEnd: returnCode: contextInfo:) contextInfo:nil];
}

- (void)openPanelDidEnd:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo;
{
  NSOpenPanel * oPanel = (NSOpenPanel *)sheet;
  NSString * path = [[oPanel filenames] objectAtIndex:0];
  if( returnCode == NSOKButton ) {
    NSString *error;
    NSPropertyListFormat format;
    NSData *plistData = [NSData dataWithContentsOfFile:path];
    id plist = [NSPropertyListSerialization propertyListFromData:plistData mutabilityOption:NSPropertyListImmutable format:&format errorDescription:&error];
    if(!plist) { NSLog(error); [error release]; }
    else { lastSettings = [plist retain]; [self copyInternalSettingsToUI]; }
  }
}

- (IBAction)save:(id)sender;
{
  NSSavePanel * sPanel = [NSSavePanel savePanel];
  [sPanel setRequiredFileType:@"ftx"];
  [sPanel beginSheetForDirectory:nil file:@"Untitled.ftx" modalForWindow:[view window] modalDelegate:self didEndSelector:@selector(savePanelDidEnd: returnCode: contextInfo:) contextInfo:nil];
}

- (void)savePanelDidEnd:(NSWindow *)sheet returnCode:(int)returnCode contextInfo:(void *)contextInfo;
{
  NSSavePanel * sPanel = (NSSavePanel *)sheet;
  if( returnCode == NSOKButton ) {
    NSData *xmlData;
    NSString *error;
    xmlData = [NSPropertyListSerialization dataFromPropertyList:lastSettings format:NSPropertyListXMLFormat_v1_0 errorDescription:&error];
    if(xmlData) { [xmlData writeToFile:[sPanel filename] atomically:YES]; }
    else { NSLog(error); [error release]; }
  }
}


#pragma mark -

// API
- (int)drawStyle;
{
  return [drawStyleUI indexOfSelectedItem];
}
- (float)lengthFactor;
{
  float fact = pow( [lengthUI floatValue], 0.5 );
  return fact;
}
- (float)angleTerm;
{
  return M_PI*[angleUI floatValue];
}
- (float)thickFactor;
{
  if( [thickUI floatValue] < 0.001 ) { return 0.001; }
  else { return [thickUI floatValue]; }
}
- (int)height;
{
  if( [heightUI intValue] == 0 ) { NSBeep(); }
  return [heightUI intValue];
}



@end
