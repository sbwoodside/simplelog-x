/* ***** BEGIN LICENSE BLOCK *****
 * Copyright (c) 2002-4 Simon Woodside.
 * Original Author: Simon Woodside <sbwoodside@yahoo.com>
 * This file is part of FractalTrees.
 *     FractalTrees is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *     FractalTrees is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *     You should have received a copy of the GNU General Public License
 * along with FractalTrees; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * ***** END LICENSE BLOCK ***** */

#import <Foundation/Foundation.h>

// Lots and lots of these get created
@interface FractalBranch : NSObject
{
  float abstractLength;	// Relative length to 1 abstract "branch length unit"
  float abstractAngle;	// In radians
  
  NSPoint basePoint;
  NSPoint endPoint;
  float length;
  float angle;
  float arcPosition;	// 0.0 is the leftmost branch in the crown, 1.0 is the rightmost
  float thickness;
  FractalBranch * left;
  FractalBranch * right;
}

+ (float)arcPositionForIndex:(int)index maxLevel:(int)max;

- (FractalBranch*)left;
- (FractalBranch*)right;
- (void)setLeft:(FractalBranch*)newLeft;
- (void)setRight:(FractalBranch*)newRight;

- (float)abstractLength;
- (float)abstractAngle;
- (NSPoint)basePoint;
- (NSPoint)endPoint;
- (float)length;
- (float)angle;
- (float)arcPosition;
- (float)thickness;
- (void)setAbstractLength:(float)newLength;
- (void)setAbstractAngle:(float)newAngle;
- (void)setBasePoint:(NSPoint)newBase;
- (void)setEndPoint:(NSPoint)newEnd;
- (void)setLength:(float)newLength;
- (void)setAngle:(float)newAngle;
//- (void)setPositionForIndex:(int)index maxLevel:(int)level;
- (void)setThickness:(float)newThick;
- (void)setArcPosition:(float)arc;
- (void)setLength:(float)newLength angle:(float)newAngle arcPosition:(float)newPosition basePoint:(NSPoint)newBase;
- (NSRect)normalizedRect;

@end
